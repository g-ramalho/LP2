namespace Ptriangulo
{
    public partial class Form1 : Form
    {

        double A, B, C;

        public Form1()
        {
            InitializeComponent();
        }

        private void TxtValorA_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (!Double.TryParse(txtValorA.Text, out A) || A < 1)
            {
                errorProvider1.SetError(txtValorA, "O n�mero inserido � inv�lido!");
                txtValorA.Focus();
            }
            else
            {
                errorProvider1.Clear();
            }
        }

        private void TxtValorB_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (!Double.TryParse(txtValorB.Text, out B) || B < 1)
            {
                errorProvider1.SetError(txtValorB, "O n�mero inserido � inv�lido!");
                txtValorB.Focus();
            }
            else
            {
                errorProvider1.Clear();
            }
        }

        private void TxtValorC_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (!Double.TryParse(txtValorC.Text, out C) || C < 1)
            {
                errorProvider1.SetError(txtValorC, "O n�mero inserido � inv�lido!");
                txtValorC.Focus();
            }
            else
            {
                errorProvider1.Clear();
            }
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            A = 0; B = 0; C = 0;

            txtValorA.Clear();
            txtValorB.Clear();
            txtValorC.Clear();

            txtValorA.Focus();
        }

        private void BtnExecuta_Click(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtValorC.Text, out C) || C < 1)
            {
                errorProvider1.SetError(txtValorC, "O n�mero inserido � inv�lido!");
                txtValorC.Focus();
            }
            else if (!Double.TryParse(txtValorB.Text, out B) || B < 1)
            {
                errorProvider1.SetError(txtValorB, "O n�mero inserido � inv�lido!");
                txtValorB.Focus();
            }
            else if (!Double.TryParse(txtValorA.Text, out A) || A < 1)
            {
                errorProvider1.SetError(txtValorA, "O n�mero inserido � inv�lido!");
                txtValorA.Focus();
            }
            else
            {
                if ((Math.Abs(B - C) < A && A < B + C) ||
                    (Math.Abs(A - C) < B && B < A + C) ||
                    (Math.Abs(A - B) < C && C < A + B))
                {
                    if (A == B && B == C)
                    {
                        MessageBox.Show("Tri�ngulo equil�tero");
                    }
                    else if ((A == B && B != C) ||
                             (A == C && B != C) ||
                             (B == C && C != A))
                    {
                        MessageBox.Show("Tri�ngulo is�sceles");
                    }
                    else
                    {
                        MessageBox.Show("Tri�ngulo escaleno");
                    }
                }
                else
                {
                    MessageBox.Show("Os valores inseridos n�o formam um tri�ngulo");
                }
            }
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Deseja realmente sair?", "Sair",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question) ==
                DialogResult.Yes) {

                Close();
            }
        }
    }
}
