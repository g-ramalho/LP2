﻿namespace Ptriangulo
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            btnExecuta = new Button();
            btnLimpar = new Button();
            btnSair = new Button();
            txtValorA = new TextBox();
            txtValorB = new TextBox();
            txtValorC = new TextBox();
            lblValorA = new Label();
            lblValorB = new Label();
            lblValorC = new Label();
            errorProvider1 = new ErrorProvider(components);
            ((System.ComponentModel.ISupportInitialize)errorProvider1).BeginInit();
            SuspendLayout();
            // 
            // btnExecuta
            // 
            btnExecuta.Location = new Point(97, 352);
            btnExecuta.Name = "btnExecuta";
            btnExecuta.Size = new Size(112, 34);
            btnExecuta.TabIndex = 0;
            btnExecuta.Text = "Executa";
            btnExecuta.UseVisualStyleBackColor = true;
            btnExecuta.Click += BtnExecuta_Click;
            // 
            // btnLimpar
            // 
            btnLimpar.Location = new Point(284, 352);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(112, 34);
            btnLimpar.TabIndex = 1;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = true;
            btnLimpar.Click += BtnLimpar_Click;
            // 
            // btnSair
            // 
            btnSair.Location = new Point(588, 352);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(112, 34);
            btnSair.TabIndex = 2;
            btnSair.Text = "Sair";
            btnSair.UseVisualStyleBackColor = true;
            btnSair.Click += BtnSair_Click;
            // 
            // txtValorA
            // 
            txtValorA.Location = new Point(210, 55);
            txtValorA.Name = "txtValorA";
            txtValorA.Size = new Size(222, 31);
            txtValorA.TabIndex = 3;
            txtValorA.Validating += TxtValorA_Validating;
            // 
            // txtValorB
            // 
            txtValorB.Location = new Point(210, 135);
            txtValorB.Name = "txtValorB";
            txtValorB.Size = new Size(222, 31);
            txtValorB.TabIndex = 4;
            txtValorB.Validating += TxtValorB_Validating;
            // 
            // txtValorC
            // 
            txtValorC.Location = new Point(210, 214);
            txtValorC.Name = "txtValorC";
            txtValorC.Size = new Size(222, 31);
            txtValorC.TabIndex = 5;
            txtValorC.Validating += TxtValorC_Validating;
            // 
            // lblValorA
            // 
            lblValorA.AutoSize = true;
            lblValorA.Location = new Point(97, 61);
            lblValorA.Name = "lblValorA";
            lblValorA.Size = new Size(94, 25);
            lblValorA.TabIndex = 6;
            lblValorA.Text = "Valor de A";
            // 
            // lblValorB
            // 
            lblValorB.AutoSize = true;
            lblValorB.Location = new Point(97, 141);
            lblValorB.Name = "lblValorB";
            lblValorB.Size = new Size(92, 25);
            lblValorB.TabIndex = 7;
            lblValorB.Text = "Valor de B";
            // 
            // lblValorC
            // 
            lblValorC.AutoSize = true;
            lblValorC.Location = new Point(97, 217);
            lblValorC.Name = "lblValorC";
            lblValorC.Size = new Size(93, 25);
            lblValorC.TabIndex = 8;
            lblValorC.Text = "Valor de C";
            // 
            // errorProvider1
            // 
            errorProvider1.ContainerControl = this;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(lblValorC);
            Controls.Add(lblValorB);
            Controls.Add(lblValorA);
            Controls.Add(txtValorC);
            Controls.Add(txtValorB);
            Controls.Add(txtValorA);
            Controls.Add(btnSair);
            Controls.Add(btnLimpar);
            Controls.Add(btnExecuta);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)errorProvider1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnExecuta;
        private Button btnLimpar;
        private Button btnSair;
        private TextBox txtValorA;
        private TextBox txtValorB;
        private TextBox txtValorC;
        private Label lblValorA;
        private Label lblValorB;
        private Label lblValorC;
        private ErrorProvider errorProvider1;
    }
}
