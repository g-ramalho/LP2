﻿using System;
using System.Windows.Forms;

namespace PTesteMetodos.Forms
{
    public partial class FrmExercicio2 : Form
    {
        public FrmExercicio2()
        {
            InitializeComponent();
        }

        private void btnCompararPalavra_Click(object sender, EventArgs e)
        {
            if (String.Compare(txtPalavra1.Text, txtPalavra2.Text) == 0)
            {
                MessageBox.Show("Iguais");
            }
            else
            {
                MessageBox.Show("Diferentes");
            }
        }

        private void btnInserirMeio_Click(object sender, EventArgs e)
        {
            int meio = txtPalavra2.Text.Length / 2;

            string metade1 = txtPalavra2.Text.Substring(0, meio);
            string metade2 = txtPalavra2.Text.Substring(meio);

            txtPalavra2.Text = metade1 + txtPalavra1.Text + metade2;
        }

        private void btnInserirAsteriscos_Click(object sender, EventArgs e)
        {
            int meio = txtPalavra1.Text.Length / 2;

            txtPalavra2.Text = txtPalavra1.Text.Insert(meio, "**");
        }
    }
}
