﻿using System;
using System.Windows.Forms;

namespace PTesteMetodos.Forms
{
    public partial class FrmExercicio4 : Form
    {
        public FrmExercicio4()
        {
            InitializeComponent();
        }

        private void btnContarNumericos_Click(object sender, EventArgs e)
        {
            int i = 0;
            int count = 0;

            while (i < rhtxtFrase.Text.Length)
            {
                if (Char.IsNumber(rhtxtFrase.Text[i]))
                {
                    count++;
                }

                i++;
            }

            MessageBox.Show(count.ToString());
        }

        private void btnEncontrarEspaco_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < rhtxtFrase.Text.Length; i++)
            {
                if (Char.IsWhiteSpace(rhtxtFrase.Text[i]))
                {
                    MessageBox.Show($"Posição: {i + 1}");
                    
                    return;
                }
            }

            MessageBox.Show("Não encontrado");
        }

        private void btnContarAlfabeticos_Click(object sender, EventArgs e)
        {
            int count = 0;

            foreach (var ch in rhtxtFrase.Text)
            {
                if (Char.IsLetter(ch)) count++;
            }

            MessageBox.Show(count.ToString());
        }
    }
}
