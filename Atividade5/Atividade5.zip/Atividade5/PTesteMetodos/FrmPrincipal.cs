﻿using PTesteMetodos.Forms;
using System;
using System.Linq;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class FrmPrincipal : Form
    {
        public FrmPrincipal()
        {
            InitializeComponent();
        }

        private void exercicio2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmExercicio2>().Count() > 0)
            {
                Application.OpenForms[new FrmExercicio2().Name].BringToFront();
            }
            else
            {
                FrmExercicio2 obj = new FrmExercicio2();
                obj.MdiParent = this;
                obj.WindowState = FormWindowState.Maximized;
                obj.Show();
            }
        }

        private void exercicio3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmExercicio3>().Count() > 0)
            {
                Application.OpenForms[new FrmExercicio3().Name].BringToFront();
            }
            else
            {
                FrmExercicio3 obj = new FrmExercicio3();
                obj.MdiParent = this;
                obj.WindowState = FormWindowState.Maximized;
                obj.Show();
            }
        }

        private void exercicio4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmExercicio4>().Count() > 0)
            {
                Application.OpenForms[new FrmExercicio4().Name].BringToFront();
            }
            else
            {
                FrmExercicio4 obj = new FrmExercicio4();
                obj.MdiParent = this;
                obj.WindowState = FormWindowState.Maximized;
                obj.Show();
            }
        }

        private void exercicio5ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmExercicio5>().Count() > 0)
            {
                Application.OpenForms[new FrmExercicio5().Name].BringToFront();
            }
            else
            {
                FrmExercicio5 obj = new FrmExercicio5();
                obj.MdiParent = this;
                obj.WindowState = FormWindowState.Maximized;
                obj.Show();
            }
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
