﻿namespace Pimc
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            txtImc = new TextBox();
            lblImc = new Label();
            lblAltura = new Label();
            lblPeso = new Label();
            btnCalcular = new Button();
            btnLimpar = new Button();
            btnSair = new Button();
            mskbxPeso = new MaskedTextBox();
            mskbxAltura = new MaskedTextBox();
            errorProvider1 = new ErrorProvider(components);
            errorProvider2 = new ErrorProvider(components);
            ((System.ComponentModel.ISupportInitialize)errorProvider1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)errorProvider2).BeginInit();
            SuspendLayout();
            // 
            // txtImc
            // 
            txtImc.Enabled = false;
            txtImc.Location = new Point(203, 205);
            txtImc.Multiline = true;
            txtImc.Name = "txtImc";
            txtImc.Size = new Size(323, 93);
            txtImc.TabIndex = 2;
            // 
            // lblImc
            // 
            lblImc.AutoSize = true;
            lblImc.Location = new Point(153, 241);
            lblImc.Name = "lblImc";
            lblImc.Size = new Size(44, 25);
            lblImc.TabIndex = 3;
            lblImc.Text = "IMC";
            // 
            // lblAltura
            // 
            lblAltura.AutoSize = true;
            lblAltura.Location = new Point(138, 112);
            lblAltura.Name = "lblAltura";
            lblAltura.Size = new Size(59, 25);
            lblAltura.TabIndex = 4;
            lblAltura.Text = "Altura";
            // 
            // lblPeso
            // 
            lblPeso.AutoSize = true;
            lblPeso.Location = new Point(102, 58);
            lblPeso.Name = "lblPeso";
            lblPeso.Size = new Size(95, 25);
            lblPeso.TabIndex = 4;
            lblPeso.Text = "Peso Atual";
            // 
            // btnCalcular
            // 
            btnCalcular.Location = new Point(102, 350);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(132, 51);
            btnCalcular.TabIndex = 5;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += BtnCalcular_Click;
            // 
            // btnLimpar
            // 
            btnLimpar.Location = new Point(339, 350);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(132, 51);
            btnLimpar.TabIndex = 6;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = true;
            btnLimpar.Click += BtnLimpar_Click;
            // 
            // btnSair
            // 
            btnSair.Location = new Point(572, 350);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(132, 51);
            btnSair.TabIndex = 7;
            btnSair.Text = "Sair";
            btnSair.UseVisualStyleBackColor = true;
            btnSair.Click += BtnSair_Click;
            // 
            // mskbxPeso
            // 
            mskbxPeso.Location = new Point(203, 58);
            mskbxPeso.Mask = "900.00";
            mskbxPeso.Name = "mskbxPeso";
            mskbxPeso.Size = new Size(323, 31);
            mskbxPeso.TabIndex = 8;
            mskbxPeso.MouseClick += MskbxPeso_MouseClick;
            mskbxPeso.Validating += MskbxPeso_Validating;
            // 
            // mskbxAltura
            // 
            mskbxAltura.Location = new Point(203, 112);
            mskbxAltura.Mask = "0.00";
            mskbxAltura.Name = "mskbxAltura";
            mskbxAltura.Size = new Size(323, 31);
            mskbxAltura.TabIndex = 9;
            mskbxAltura.Click += MskbxAltura_Click;
            mskbxAltura.Validating += MskbxAltura_Validating;
            // 
            // errorProvider1
            // 
            errorProvider1.ContainerControl = this;
            // 
            // errorProvider2
            // 
            errorProvider2.ContainerControl = this;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(mskbxAltura);
            Controls.Add(mskbxPeso);
            Controls.Add(btnSair);
            Controls.Add(btnLimpar);
            Controls.Add(btnCalcular);
            Controls.Add(lblPeso);
            Controls.Add(lblAltura);
            Controls.Add(lblImc);
            Controls.Add(txtImc);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)errorProvider1).EndInit();
            ((System.ComponentModel.ISupportInitialize)errorProvider2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private TextBox txtImc;
        private Label lblImc;
        private Label lblAltura;
        private Label lblPeso;
        private Button btnCalcular;
        private Button btnLimpar;
        private Button btnSair;
        private MaskedTextBox mskbxPeso;
        private MaskedTextBox mskbxAltura;
        private ErrorProvider errorProvider1;
        private ErrorProvider errorProvider2;
    }
}
