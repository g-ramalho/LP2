namespace Pimc
{
    public partial class Form1 : Form
    {
        double peso, altura, imc;
        string diag;

        public Form1()
        {
            InitializeComponent();
        }

        private void MskbxPeso_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
           if (!Double.TryParse(mskbxPeso.Text, out peso))
            {
                errorProvider1.SetError(mskbxPeso, "O peso inserido � inv�lido");
                mskbxPeso.Focus();
                btnCalcular.Enabled = false;
            }
            else
            {
                btnCalcular.Enabled = true;
            }
        }

        private void MskbxAltura_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (mskbxAltura.Text == "" || mskbxAltura.Text == " ,") { return; }
            if (!Double.TryParse(mskbxAltura.Text, out altura) || altura <= 0)
            {
                errorProvider2.SetError(mskbxAltura, "A altura inserida � inv�lida");
                mskbxAltura.Focus();
                btnCalcular.Enabled = false;
            }
            else
            {
                btnCalcular.Enabled = true;
            }
        }

        private void BtnCalcular_Click(object sender, EventArgs e)
        {
            imc = peso / Math.Pow(altura, 2);
            imc = Math.Round(imc, 1);

            if (imc < 18.5)
            {
                diag = "MAGREZA" + Environment.NewLine + "Grau: 0";
            }
            else if (imc <= 24.9)
            {
                diag = "NORMAL" + Environment.NewLine + "Grau: 0";
            }
            else if (imc <= 29.9)
            {
                diag = "SOBREPESO" + Environment.NewLine + "Grau: I";
            }
            else if (imc <= 39.9)
            {
                diag = "OBESIDADE" + Environment.NewLine + "Grau: II";
            }
            else if (imc >= 40)
            {
                diag = "OBESIDADE GRAVE" + Environment.NewLine + "Grau: III";
            }

            txtImc.Text = imc.ToString("N1") + Environment.NewLine + "Diagn�stico: " + diag;
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            peso = 0; imc = 0; altura = 0;
            mskbxPeso.Text = "";
            mskbxAltura.Text = "";
        }

        private void MskbxPeso_MouseClick(object sender, MouseEventArgs e)
        {
            mskbxPeso.Text = "";
        }

        private void MskbxAltura_Click(object sender, EventArgs e)
        {
            mskbxAltura.Text = "";
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Deseja fechar a aplica��o?", "Sair", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                Close();
            }
        }
    }
}
