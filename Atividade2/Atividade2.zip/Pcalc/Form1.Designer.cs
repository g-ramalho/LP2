﻿namespace Pcalc
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            txtNumero1 = new TextBox();
            txtNumero2 = new TextBox();
            txtResultado = new TextBox();
            lblNumero1 = new Label();
            lblNumero2 = new Label();
            lblResultado = new Label();
            btnAdd = new Button();
            btnSub = new Button();
            btnMult = new Button();
            btnDiv = new Button();
            btnLimpar = new Button();
            btnSair = new Button();
            errorProvider1 = new ErrorProvider(components);
            ((System.ComponentModel.ISupportInitialize)errorProvider1).BeginInit();
            SuspendLayout();
            // 
            // txtNumero1
            // 
            txtNumero1.Location = new Point(159, 75);
            txtNumero1.Name = "txtNumero1";
            txtNumero1.Size = new Size(300, 31);
            txtNumero1.TabIndex = 0;
            txtNumero1.Validating += TxtNumero1_Validating;
            // 
            // txtNumero2
            // 
            txtNumero2.Location = new Point(159, 134);
            txtNumero2.Name = "txtNumero2";
            txtNumero2.Size = new Size(300, 31);
            txtNumero2.TabIndex = 1;
            txtNumero2.Validating += TxtNumero2_Validating;
            // 
            // txtResultado
            // 
            txtResultado.Enabled = false;
            txtResultado.Location = new Point(159, 256);
            txtResultado.Name = "txtResultado";
            txtResultado.Size = new Size(300, 31);
            txtResultado.TabIndex = 2;
            // 
            // lblNumero1
            // 
            lblNumero1.AutoSize = true;
            lblNumero1.Location = new Point(33, 75);
            lblNumero1.Name = "lblNumero1";
            lblNumero1.Size = new Size(92, 25);
            lblNumero1.TabIndex = 3;
            lblNumero1.Text = "Número 1";
            // 
            // lblNumero2
            // 
            lblNumero2.AutoSize = true;
            lblNumero2.Location = new Point(33, 134);
            lblNumero2.Name = "lblNumero2";
            lblNumero2.Size = new Size(92, 25);
            lblNumero2.TabIndex = 4;
            lblNumero2.Text = "Número 2";
            // 
            // lblResultado
            // 
            lblResultado.AutoSize = true;
            lblResultado.Location = new Point(33, 256);
            lblResultado.Name = "lblResultado";
            lblResultado.Size = new Size(90, 25);
            lblResultado.TabIndex = 5;
            lblResultado.Text = "Resultado";
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(68, 353);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(87, 75);
            btnAdd.TabIndex = 6;
            btnAdd.Text = "+";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += BtnAdd_Click;
            // 
            // btnSub
            // 
            btnSub.Location = new Point(208, 353);
            btnSub.Name = "btnSub";
            btnSub.Size = new Size(87, 75);
            btnSub.TabIndex = 7;
            btnSub.Text = "-";
            btnSub.UseVisualStyleBackColor = true;
            btnSub.Click += BtnSub_Click;
            // 
            // btnMult
            // 
            btnMult.Location = new Point(356, 353);
            btnMult.Name = "btnMult";
            btnMult.Size = new Size(87, 75);
            btnMult.TabIndex = 8;
            btnMult.Text = "*";
            btnMult.UseVisualStyleBackColor = true;
            btnMult.Click += BtnMult_Click;
            // 
            // btnDiv
            // 
            btnDiv.Location = new Point(503, 353);
            btnDiv.Name = "btnDiv";
            btnDiv.Size = new Size(87, 75);
            btnDiv.TabIndex = 9;
            btnDiv.Text = "/";
            btnDiv.UseVisualStyleBackColor = true;
            btnDiv.Click += BtnDiv_Click;
            // 
            // btnLimpar
            // 
            btnLimpar.Location = new Point(614, 75);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(87, 75);
            btnLimpar.TabIndex = 10;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = true;
            btnLimpar.Click += BtnLimpar_Click;
            // 
            // btnSair
            // 
            btnSair.Location = new Point(614, 206);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(87, 75);
            btnSair.TabIndex = 11;
            btnSair.Text = "Sair";
            btnSair.UseVisualStyleBackColor = true;
            btnSair.Click += BtnSair_Click;
            // 
            // errorProvider1
            // 
            errorProvider1.ContainerControl = this;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(852, 473);
            Controls.Add(btnSair);
            Controls.Add(btnLimpar);
            Controls.Add(btnDiv);
            Controls.Add(btnMult);
            Controls.Add(btnSub);
            Controls.Add(btnAdd);
            Controls.Add(lblResultado);
            Controls.Add(lblNumero2);
            Controls.Add(lblNumero1);
            Controls.Add(txtResultado);
            Controls.Add(txtNumero2);
            Controls.Add(txtNumero1);
            Name = "Form1";
            Text = "Pcalc";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)errorProvider1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtNumero1;
        private TextBox txtNumero2;
        private TextBox txtResultado;
        private Label lblNumero1;
        private Label lblNumero2;
        private Label lblResultado;
        private Button btnAdd;
        private Button btnSub;
        private Button btnMult;
        private Button btnDiv;
        private Button btnLimpar;
        private Button btnSair;
        private ErrorProvider errorProvider1;
    }
}
