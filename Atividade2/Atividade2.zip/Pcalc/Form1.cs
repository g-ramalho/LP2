namespace Pcalc
{
    public partial class Form1 : Form
    {
        double numero1, numero2, resultado;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            txtNumero1.Focus();
            resultado = 0;
            numero1 = 0;
            numero2 = 0;

            txtNumero1.Clear();
            txtNumero2.Clear();
            txtResultado.Clear();
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNumero1.Text, out numero1) ||
                !Double.TryParse(txtNumero2.Text, out numero2))
            {
                txtNumero1.Focus();
            }
            else
            {
                resultado = numero1 + numero2;
                txtResultado.Text = resultado.ToString();
            }
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Voc� deseja sair mesmo?",
                "Sa�da", MessageBoxButtons.YesNo,
                MessageBoxIcon.Question) ==
                DialogResult.Yes)
            {
                Close();
            }
        }
        private void BtnSub_Click(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNumero1.Text, out numero1) ||
                !Double.TryParse(txtNumero2.Text, out numero2))
            {
                txtNumero1.Focus();
            }
            else
            {
                resultado = numero1 - numero2;
                txtResultado.Text = resultado.ToString();
            }
        }

        private void BtnMult_Click(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNumero1.Text, out numero1) ||
                !Double.TryParse(txtNumero2.Text, out numero2))
            {
                txtNumero1.Focus();
            }
            else
            {
                resultado = numero1 * numero2;
                txtResultado.Text = resultado.ToString();
            }
        }

        private void BtnDiv_Click(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNumero1.Text, out numero1) ||
                !Double.TryParse(txtNumero2.Text, out numero2))
            {
                txtNumero1.Focus();
            }
            else
            {
                if (numero2 != 0)
                {
                    resultado = numero1 / numero2;
                    txtResultado.Text = resultado.ToString();
                }
                else
                {
                    errorProvider1.SetError(txtNumero2, "N�o existem divis�es por 0!");
                    txtNumero2.Focus();
                }
            }
        }

        private void TxtNumero1_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (!Double.TryParse(txtNumero1.Text, out numero1))
            {
                errorProvider1.SetError(txtNumero1, "O n�mero inserido � inv�lido!");
                txtNumero1.Focus();
            }
            else
            {
                errorProvider1.Clear();
            }
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            txtNumero1.Focus();
            resultado = 0;
            numero1 = 0;
            numero2 = 0;

            txtNumero1.Clear();
            txtNumero2.Clear();
            txtResultado.Clear();
        }

        private void TxtNumero2_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (!Double.TryParse(txtNumero2.Text, out numero1))
            {
                errorProvider1.SetError(txtNumero2, "O n�mero inserido � inv�lido!");
                txtNumero2.Focus();
            }
            else
            {
                errorProvider1.Clear();
            }
        }
    }
}
